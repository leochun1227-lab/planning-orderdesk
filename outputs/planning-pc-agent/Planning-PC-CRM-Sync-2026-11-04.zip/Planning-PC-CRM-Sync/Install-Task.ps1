$ErrorActionPreference='Stop'
$configPath=Join-Path $PSScriptRoot 'agent-settings.json'
if(-not(Test-Path -LiteralPath $configPath)){throw 'Configure this computer first'}
$resultPath=Join-Path $PSScriptRoot 'last-run.json'
if(-not(Test-Path -LiteralPath $resultPath)){throw 'Run verification on this computer first'}
$result=Get-Content -LiteralPath $resultPath -Raw|ConvertFrom-Json
if(-not $result.ok -or -not $result.verifyOnly -or $result.matchedMessages -lt 1){throw 'A successful read-only test with an actual CRM attachment is required first'}
$taskName='OrderDesk Planning CRM Reader'
if(Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue){throw 'Task already exists. Do not install a second copy.'}
$user=[Security.Principal.WindowsIdentity]::GetCurrent().Name
$run=Join-Path $PSScriptRoot 'Run-Agent.ps1'
$powershell=Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$action=New-ScheduledTaskAction -Execute $powershell -Argument ('-NoProfile -NonInteractive -WindowStyle Hidden -File "'+$run+'"') -WorkingDirectory $PSScriptRoot
$interval=New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 15)
$logon=New-ScheduledTaskTrigger -AtLogOn -User $user
$principal=New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
$settings=New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 12) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -TaskName $taskName -Action $action -Trigger @($interval,$logon) -Principal $principal -Settings $settings -Description 'Read Planning CRM attachments via classic Outlook and upload to OrderDesk.'|Out-Null
Write-Host 'Installed: every 15 minutes and at this user logon. Keep Windows signed in and Outlook configured.'
